import { GradientApp } from './components/gradient-app';

export default function App() {
  return <GradientApp />;
}
