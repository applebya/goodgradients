
  # Gradient Gallery Page

  This is a code bundle for Gradient Gallery Page. The original project is available at https://www.figma.com/design/2zh0HwkyK3hFBZSucEUJlb/Gradient-Gallery-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  